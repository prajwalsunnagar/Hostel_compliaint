-- ============================================================
-- HOSTEL COMPLAINT MANAGEMENT SYSTEM - V1 SEED DATA
-- Database Name: hostel_complaint_manager
-- ============================================================

USE hostel_complaint_manager;

-- 1. BLOCKS
INSERT INTO BLOCK (block_id, block_name) VALUES
(1, 'IT'),
(2, 'IH'),
(3, 'NB'),
(4, 'MM')
ON DUPLICATE KEY UPDATE block_name=VALUES(block_name);

-- 2. COMPLAINT CATEGORIES
INSERT INTO COMPLAINT_CATEGORY (category_id, category_name) VALUES
(1, 'Electrical'),
(2, 'Water Supply'),
(3, 'Wi-Fi / Internet'),
(4, 'Cleanliness'),
(5, 'Food / Mess'),
(6, 'Room Maintenance'),
(7, 'Furniture'),
(8, 'Safety / Security'),
(9, 'Other')
ON DUPLICATE KEY UPDATE category_name=VALUES(category_name);

-- 3. ROOMS (Varying capacities per block)
-- Block MM (id: 4)
INSERT INTO ROOM (room_id, block_id, room_number, capacity) VALUES
(101, 4, '401', 2),
(102, 4, '402', 3),
(103, 4, '403', 4),
-- Block IT (id: 1)
(104, 1, '101', 2),
(105, 1, '102', 2),
-- Block IH (id: 2)
(106, 2, '201', 3),
-- Block NB (id: 3)
(107, 3, '301', 2)
ON DUPLICATE KEY UPDATE capacity=VALUES(capacity);

-- 4. STAFF MEMBERS
INSERT INTO STAFF (staff_id, name, email, phone, role) VALUES
(1, 'Rajesh Kumar', 'electrician@hostel.com', '+91 9876543210', 'Electrician'),
(2, 'Suresh Patel', 'plumber@hostel.com', '+91 9876543211', 'Plumber'),
(3, 'Vikram Sharma', 'network@hostel.com', '+91 9876543212', 'Network Technician'),
(4, 'Ramesh Verma', 'cleaner@hostel.com', '+91 9876543213', 'Cleaner'),
(5, 'Anil Gupta', 'carpenter@hostel.com', '+91 9876543214', 'Carpenter')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- 5. STAFF CATEGORY MAPPING (1 Category -> 1 Responsible Staff in V1)
-- Electrical (1) -> Rajesh (1)
-- Water Supply (2) -> Suresh (2)
-- Wi-Fi / Internet (3) -> Vikram (3)
-- Cleanliness (4), Food/Mess (5) -> Ramesh (4)
-- Room Maint (6), Furniture (7), Safety (8), Other (9) -> Anil (5)
INSERT INTO STAFF_CATEGORY (staff_id, category_id) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(4, 5),
(5, 6),
(5, 7),
(5, 8),
(5, 9)
ON DUPLICATE KEY UPDATE staff_id=VALUES(staff_id);

-- 6. STUDENTS
INSERT INTO STUDENT (student_id, srn, name, email, phone, room_id) VALUES
(1, 'PES1UG22CS001', 'Aarav Mehta', 'aarav.m@pes.edu', '+91 9123456780', 101),
(2, 'PES1UG22CS002', 'Rohan Das', 'rohan.d@pes.edu', '+91 9123456781', 101),
(3, 'PES1UG22CS003', 'Karan Nair', 'karan.n@pes.edu', '+91 9123456782', 102),
(4, 'PES1UG22CS004', 'Siddharth Rao', 'siddharth.r@pes.edu', '+91 9123456783', 102),
(5, 'PES1UG22CS005', 'Varun Singh', 'varun.s@pes.edu', '+91 9123456784', 102)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- 7. USER ACCOUNTS (Passwords pre-hashed or plain demo: 'password123')
-- SHA-256 / bcrypt hash for 'password123': $2a$10$7R4/0pP8.v.5y0Xq.1v6O.123456789 (or plain fallback matching controller)
INSERT INTO USER_ACCOUNT (user_id, username, password_hash, role, student_id, staff_id) VALUES
-- Warden Account
(1, 'warden', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'WARDEN', NULL, NULL),
-- Student Accounts
(2, 'PES1UG22CS001', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'STUDENT', 1, NULL),
(3, 'PES1UG22CS002', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'STUDENT', 2, NULL),
(4, 'PES1UG22CS003', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'STUDENT', 3, NULL),
-- Staff Accounts
(5, 'electrician', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'STAFF', NULL, 1),
(6, 'plumber', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'STAFF', NULL, 2),
(7, 'network', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'STAFF', NULL, 3),
(8, 'cleaner', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'STAFF', NULL, 4),
(9, 'carpenter', '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', 'STAFF', NULL, 5)
ON DUPLICATE KEY UPDATE username=VALUES(username);
