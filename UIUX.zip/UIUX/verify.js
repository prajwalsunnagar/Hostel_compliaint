const http = require('http');
const path = require('path');
const fs = require('fs');

process.env.PORT = '5000';
process.env.JWT_SECRET = 'hostel_complaint_secret_key_2026_v1_super_secure';

const app = require('./backend/server');

function makeRequest(method, path, body = null, token = null) {
    return new Promise((resolve, reject) => {
        const headers = {};
        let requestBody = null;

        if (body) {
            headers['Content-Type'] = 'application/json';
            requestBody = JSON.stringify(body);
        }
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const req = http.request({
            hostname: 'localhost',
            port: 5000,
            path: path,
            method: method,
            headers: headers
        }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    resolve({ status: res.statusCode, data: parsed });
                } catch (e) {
                    resolve({ status: res.statusCode, raw: data });
                }
            });
        });

        req.on('error', reject);
        if (requestBody) req.write(requestBody);
        req.end();
    });
}

async function runTests() {
    console.log('\n======================================================');
    console.log(' 🧪 HOSTEL COMPLAINT SYSTEM V1 - AUTOMATED TEST SUITE');
    console.log('======================================================\n');

    let passed = 0;
    let failed = 0;

    function assert(condition, message) {
        if (condition) {
            console.log(` ✅ PASS: ${message}`);
            passed++;
        } else {
            console.error(` ❌ FAIL: ${message}`);
            failed++;
        }
    }

    try {
        // 1. Health Check
        const health = await makeRequest('GET', '/api/health');
        assert(health.status === 200 && health.data.status === 'online', 'Backend Health Endpoint OK');

        // 2. Student Authentication
        const studentLogin = await makeRequest('POST', '/api/auth/login', {
            username: 'PES1UG22CS001',
            password: 'password123'
        });
        assert(studentLogin.status === 200 && studentLogin.data.token, 'Student Authentication & JWT Generation');
        const studentToken = studentLogin.data.token;

        // 3. Staff Authentication
        const staffLogin = await makeRequest('POST', '/api/auth/login', {
            username: 'electrician',
            password: 'password123'
        });
        assert(staffLogin.status === 200 && staffLogin.data.token, 'Staff Authentication & JWT Generation');
        const staffToken = staffLogin.data.token;

        // 4. Warden Authentication
        const wardenLogin = await makeRequest('POST', '/api/auth/login', {
            username: 'warden',
            password: 'admin123'
        });
        assert(wardenLogin.status === 200 && wardenLogin.data.token, 'Warden Authentication & JWT Generation');
        const wardenToken = wardenLogin.data.token;

        // 5. Student Identity Auto-Retrieval
        const dashboard = await makeRequest('GET', '/api/student/dashboard', null, studentToken);
        assert(
            dashboard.status === 200 && 
            dashboard.data.dashboard.srn === 'PES1UG22CS001' && 
            dashboard.data.dashboard.block.block_name === 'MM' && 
            dashboard.data.dashboard.room.room_number === '401',
            'Student Dashboard & Hostel Identity Auto-Retrieval'
        );

        // 6. Automatic Category Staff Assignment
        const newComplaint = await makeRequest('POST', '/api/complaints', {
            category_id: 1,
            title: 'Water Heater Not Heating',
            description: 'The geyser in Room 401 bathroom is not heating water.',
            priority: 'High'
        }, studentToken);

        assert(
            newComplaint.status === 201 && 
            newComplaint.data.complaint &&
            newComplaint.data.complaint.reported_by === 1 && 
            newComplaint.data.complaint.room_id === 101 && 
            newComplaint.data.complaint.assigned_staff_name === 'Rajesh Kumar',
            'Complaint Submission & Category-Based Automatic Staff Assignment'
        );

        const complaintId = newComplaint.data.complaint.complaint_id;

        // 7. Security Rule Verification
        const forgedComplaint = await makeRequest('POST', '/api/complaints', {
            reported_by: 999,
            room_id: 888,
            category_id: 2,
            title: 'Leaking Tap',
            description: 'Bathroom faucet is dripping water continuously.',
            priority: 'Medium'
        }, studentToken);

        assert(
            forgedComplaint.status === 201 && 
            forgedComplaint.data.complaint.reported_by === 1 && 
            forgedComplaint.data.complaint.room_id === 101,
            'Security Enforcement: Backend overrides forged student_id/room_id with authenticated user context'
        );

        // 8. Staff Worklist
        const staffComplaints = await makeRequest('GET', '/api/complaints', null, staffToken);
        assert(
            staffComplaints.status === 200 && 
            staffComplaints.data.complaints.length > 0 &&
            staffComplaints.data.complaints.some(c => c.complaint_id === complaintId),
            'Staff Worklist Views Assigned Complaint'
        );

        // 9. Status Transitions & History Remarks
        const updateStatus = await makeRequest('PATCH', `/api/complaints/${complaintId}/status`, {
            status: 'In Progress',
            remarks: 'Technician inspected geyser wiring. Replacing thermostat.'
        }, staffToken);

        assert(
            updateStatus.status === 200 && updateStatus.data.status === 'In Progress',
            'Staff Status Update to In Progress with Remarks'
        );

        const resolveStatus = await makeRequest('PATCH', `/api/complaints/${complaintId}/status`, {
            status: 'Resolved',
            remarks: 'Thermostat replaced. Geyser tested and heating correctly.'
        }, staffToken);

        assert(
            resolveStatus.status === 200 && resolveStatus.data.status === 'Resolved',
            'Staff Status Update to Resolved with Remarks & Timestamp'
        );

        // 10. Student Status Tracking
        const studentComplaints = await makeRequest('GET', '/api/complaints', null, studentToken);
        const resolvedComp = studentComplaints.data.complaints.find(c => c.complaint_id === complaintId);

        assert(
            resolvedComp && 
            resolvedComp.status === 'Resolved' && 
            resolvedComp.history.length >= 2,
            'Student Tracks Updated Status & Full Status History Audit Log'
        );

        // 11. Warden Admin Operations
        const newRoom = await makeRequest('POST', '/api/rooms/rooms/create', {
            block_id: 4,
            room_number: '404',
            capacity: 3
        }, wardenToken);
        assert(newRoom.status === 201, 'Warden Creates Room with Configurable Capacity');

        const newStudent = await makeRequest('POST', '/api/student/create', {
            srn: 'PES1UG22CS099',
            name: 'Vikramaditya Roy',
            email: 'vikram.roy@pes.edu',
            phone: '+91 9988776655',
            room_id: newRoom.data.room.room_id
        }, wardenToken);
        assert(newStudent.status === 201 && newStudent.data.student.credentials.username === 'PES1UG22CS099', 'Warden Creates Student Account');

        console.log('\n======================================================');
        console.log(` 📊 SUMMARY: ${passed} PASSED | ${failed} FAILED`);
        console.log('======================================================\n');

        process.exit(failed === 0 ? 0 : 1);
    } catch (err) {
        console.error('Test Suite Error:', err);
        process.exit(1);
    }
}

setTimeout(runTests, 1000);
