/* ============================================================
   HOSTEL COMPLAINT MANAGEMENT SYSTEM - FRONTEND APP (V1)
   ============================================================ */

const API_BASE = '/api';

// Application State
const state = {
    token: localStorage.getItem('token') || null,
    user: JSON.parse(localStorage.getItem('user')) || null,
    categories: [],
    blocks: [],
    rooms: [],
    studentComplaints: [],
    staffComplaints: [],
    allComplaints: [],
    selectedFiles: []
};

// DOM Initialization
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    setupEventListeners();

    if (state.token && state.user) {
        restoreSession();
    } else {
        showView('authSection');
    }
});

// Theme Toggle
function initTheme() {
    const themeBtn = document.getElementById('themeToggle');
    const isLight = localStorage.getItem('theme') === 'light';
    if (isLight) {
        document.body.classList.add('light-theme');
        themeBtn.innerHTML = '<i class="fa-solid fa-sun"></i>';
    }

    themeBtn.addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
        const currentLight = document.body.classList.contains('light-theme');
        localStorage.setItem('theme', currentLight ? 'light' : 'dark');
        themeBtn.innerHTML = currentLight ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
    });
}

// Global Event Listeners
function setupEventListeners() {
    // Login form submit
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);

    // Student complaint creation form
    document.getElementById('complaintForm').addEventListener('submit', handleComplaintSubmit);

    // Media file preview setup
    const fileInput = document.getElementById('compMedia');
    fileInput.addEventListener('change', handleFileSelect);

    // Warden forms
    document.getElementById('createStudentForm').addEventListener('submit', handleCreateStudent);
    document.getElementById('createStaffForm').addEventListener('submit', handleCreateStaff);
    document.getElementById('createRoomForm').addEventListener('submit', handleCreateRoom);

    // Status update modal form
    document.getElementById('statusUpdateForm').addEventListener('submit', handleStatusUpdateSubmit);
}

// Quick Demo Login Helper
window.quickLogin = function(username, password) {
    document.getElementById('loginUsername').value = username;
    document.getElementById('loginPassword').value = password;
    document.getElementById('loginForm').dispatchEvent(new Event('submit'));
};

// API Fetch Wrapper
async function apiFetch(endpoint, options = {}) {
    const headers = options.headers || {};
    if (state.token) {
        headers['Authorization'] = `Bearer ${state.token}`;
    }
    if (!(options.body instanceof FormData)) {
        headers['Content-Type'] = 'application/json';
    }

    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            ...options,
            headers
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.message || 'API request failed');
        }
        return data;
    } catch (err) {
        console.error(`API Error [${endpoint}]:`, err);
        throw err;
    }
}

// Auth Login Handler
async function handleLogin(e) {
    e.preventDefault();
    const alertBox = document.getElementById('loginAlert');
    alertBox.classList.add('hidden');

    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value.trim();

    try {
        const res = await apiFetch('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });

        state.token = res.token;
        state.user = res.user;
        localStorage.setItem('token', res.token);
        localStorage.setItem('user', JSON.stringify(res.user));

        renderUserNav();
        routeRoleView();
    } catch (err) {
        alertBox.textContent = err.message || 'Login failed.';
        alertBox.classList.remove('hidden');
    }
}

// Session Restoration
function restoreSession() {
    renderUserNav();
    routeRoleView();
}

// Render User Navigation Bar
function renderUserNav() {
    const userInfo = document.getElementById('userInfo');
    const roleTag = document.getElementById('userRoleTag');
    const nameTag = document.getElementById('userNameTag');
    const logoutBtn = document.getElementById('logoutBtn');

    if (state.user) {
        userInfo.classList.remove('hidden');
        logoutBtn.classList.remove('hidden');

        roleTag.textContent = state.user.role;
        roleTag.className = `role-pill ${state.user.role.toLowerCase()}-pill`;

        const profileName = state.user.profile ? state.user.profile.name : state.user.username;
        nameTag.textContent = profileName;
    } else {
        userInfo.classList.add('hidden');
        logoutBtn.classList.add('hidden');
    }
}

// Logout Handler
function handleLogout() {
    state.token = null;
    state.user = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    renderUserNav();
    showView('authSection');
}

// Route User View based on Role
function routeRoleView() {
    if (!state.user) return showView('authSection');

    switch (state.user.role) {
        case 'STUDENT':
            showView('studentSection');
            loadStudentDashboard();
            break;
        case 'STAFF':
            showView('staffSection');
            loadStaffDashboard();
            break;
        case 'WARDEN':
            showView('wardenSection');
            loadWardenDashboard();
            break;
        default:
            showView('authSection');
    }
}

// View Switcher
function showView(viewId) {
    document.querySelectorAll('.view-section').forEach(sec => sec.classList.add('hidden'));
    const target = document.getElementById(viewId);
    if (target) target.classList.remove('hidden');
}

/* ============================================================
   1. STUDENT MODULE LOGIC
   ============================================================ */

async function loadStudentDashboard() {
    loadCategories();

    try {
        const res = await apiFetch('/student/dashboard');
        const dash = res.dashboard;

        document.getElementById('stuName').textContent = dash.name;
        document.getElementById('stuSrn').textContent = `SRN: ${dash.srn}`;
        document.getElementById('stuBlock').textContent = dash.block.block_name;
        document.getElementById('stuRoom').textContent = `Room ${dash.room.room_number}`;
        document.getElementById('stuCapacity').textContent = `${dash.room.capacity} Persons`;

        // Render Roommates
        const roommatesEl = document.getElementById('stuRoommates');
        if (dash.roommates && dash.roommates.length > 0) {
            roommatesEl.textContent = dash.roommates.map(r => `${r.name} (${r.srn})`).join(', ');
        } else {
            roommatesEl.textContent = 'No current roommates registered in this room.';
        }

        loadStudentComplaints();
    } catch (err) {
        console.error('Failed to load student dashboard:', err);
    }
}

async function loadCategories() {
    try {
        const res = await apiFetch('/complaints/categories');
        state.categories = res.categories;

        const select = document.getElementById('compCategory');
        select.innerHTML = '<option value="">Select Category (1 Category Per Complaint)</option>';
        state.categories.forEach(cat => {
            select.innerHTML += `<option value="${cat.category_id}">${cat.category_name}</option>`;
        });
    } catch (err) {
        console.error('Failed to load categories:', err);
    }
}

function handleFileSelect(e) {
    const files = Array.from(e.target.files);
    state.selectedFiles = files;
    renderMediaPreviews(files);
}

function renderMediaPreviews(files) {
    const container = document.getElementById('mediaPreviewContainer');
    container.innerHTML = '';

    files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
            const isVideo = file.type.startsWith('video/');
            const thumb = document.createElement('div');
            thumb.className = 'preview-thumb';
            if (isVideo) {
                thumb.innerHTML = `<video src="${event.target.result}" muted></video>`;
            } else {
                thumb.innerHTML = `<img src="${event.target.result}" alt="preview">`;
            }
            container.appendChild(thumb);
        };
        reader.readAsDataURL(file);
    });
}

async function handleComplaintSubmit(e) {
    e.preventDefault();
    const alertBox = document.getElementById('complaintAlert');
    const submitBtn = document.getElementById('submitComplaintBtn');

    alertBox.classList.add('hidden');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting...';

    const categoryId = document.getElementById('compCategory').value;
    const priority = document.querySelector('input[name="priority"]:checked')?.value || 'Medium';
    const title = document.getElementById('compTitle').value.trim();
    const description = document.getElementById('compDescription').value.trim();

    const formData = new FormData();
    formData.append('category_id', categoryId);
    formData.append('priority', priority);
    formData.append('title', title);
    formData.append('description', description);

    state.selectedFiles.forEach(file => {
        formData.append('media', file);
    });

    try {
        const res = await apiFetch('/complaints', {
            method: 'POST',
            body: formData
        });

        alertBox.className = 'alert alert-success';
        alertBox.textContent = res.message;
        alertBox.classList.remove('hidden');

        document.getElementById('complaintForm').reset();
        document.getElementById('mediaPreviewContainer').innerHTML = '';
        state.selectedFiles = [];

        // Switch tab to Track Complaints
        setTimeout(() => {
            switchStudentTab('myComplaintsTab');
            loadStudentComplaints();
        }, 1200);

    } catch (err) {
        alertBox.className = 'alert alert-error';
        alertBox.textContent = err.message || 'Failed to submit complaint.';
        alertBox.classList.remove('hidden');
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Complaint';
    }
}

async function loadStudentComplaints() {
    try {
        const res = await apiFetch('/complaints');
        state.studentComplaints = res.complaints;
        renderComplaintCards('studentComplaintsList', state.studentComplaints);
    } catch (err) {
        console.error('Failed to load student complaints:', err);
    }
}

window.switchStudentTab = function(tabId) {
    document.querySelectorAll('#studentSection .tab-content').forEach(tc => tc.classList.add('hidden'));
    document.querySelectorAll('#studentSection .tab-btn').forEach(tb => tb.classList.remove('active'));

    document.getElementById(tabId).classList.remove('hidden');
    event.currentTarget.classList.add('active');

    if (tabId === 'myComplaintsTab') {
        loadStudentComplaints();
    }
};

window.filterStudentComplaints = function(statusFilter) {
    document.querySelectorAll('#myComplaintsTab .filter-btn').forEach(fb => fb.classList.remove('active'));
    event.currentTarget.classList.add('active');

    if (statusFilter === 'all') {
        renderComplaintCards('studentComplaintsList', state.studentComplaints);
    } else {
        const filtered = state.studentComplaints.filter(c => c.status === statusFilter);
        renderComplaintCards('studentComplaintsList', filtered);
    }
};

/* ============================================================
   2. STAFF MODULE LOGIC
   ============================================================ */

async function loadStaffDashboard() {
    if (state.user && state.user.profile) {
        document.getElementById('staffName').textContent = state.user.profile.name;
        document.getElementById('staffRole').textContent = state.user.profile.role;
        document.getElementById('staffEmail').textContent = state.user.profile.email;
    }

    loadStaffComplaints();
}

async function loadStaffComplaints() {
    try {
        const res = await apiFetch('/complaints');
        state.staffComplaints = res.complaints;

        // Calculate counts
        const assigned = state.staffComplaints.length;
        const pending = state.staffComplaints.filter(c => c.status === 'Pending').length;
        const resolved = state.staffComplaints.filter(c => c.status === 'Resolved').length;

        document.getElementById('staffAssignedCount').textContent = assigned;
        document.getElementById('staffPendingCount').textContent = pending;
        document.getElementById('staffResolvedCount').textContent = resolved;

        renderComplaintCards('staffComplaintsList', state.staffComplaints, true);
    } catch (err) {
        console.error('Failed to load staff complaints:', err);
    }
}

window.filterStaffComplaints = function(statusFilter) {
    document.querySelectorAll('#staffSection .filter-btn').forEach(fb => fb.classList.remove('active'));
    event.currentTarget.classList.add('active');

    if (statusFilter === 'all') {
        renderComplaintCards('staffComplaintsList', state.staffComplaints, true);
    } else {
        const filtered = state.staffComplaints.filter(c => c.status === statusFilter);
        renderComplaintCards('staffComplaintsList', filtered, true);
    }
};

/* ============================================================
   3. WARDEN / ADMIN MODULE LOGIC
   ============================================================ */

async function loadWardenDashboard() {
    loadWardenMasterComplaints();
    loadWardenRooms();
    loadWardenStudents();
    loadWardenStaff();
    loadCategories();
}

async function loadWardenMasterComplaints() {
    try {
        const res = await apiFetch('/complaints');
        state.allComplaints = res.complaints;

        // Metric Counters
        const total = state.allComplaints.length;
        const pending = state.allComplaints.filter(c => c.status === 'Pending').length;
        const inProgress = state.allComplaints.filter(c => c.status === 'In Progress').length;
        const resolved = state.allComplaints.filter(c => c.status === 'Resolved').length;

        document.getElementById('metricTotal').textContent = total;
        document.getElementById('metricPending').textContent = pending;
        document.getElementById('metricInProgress').textContent = inProgress;
        document.getElementById('metricResolved').textContent = resolved;

        renderComplaintCards('wardenComplaintsList', state.allComplaints, true);
    } catch (err) {
        console.error('Failed to load warden master complaints:', err);
    }
}

async function loadWardenRooms() {
    try {
        const res = await apiFetch('/rooms/rooms');
        state.rooms = res.rooms;

        // Populate room select in student create form
        const select = document.getElementById('stuRoomSelect');
        select.innerHTML = '<option value="">Select Room</option>';
        state.rooms.forEach(r => {
            select.innerHTML += `<option value="${r.room_id}">${r.block_name} - Room ${r.room_number} (Cap: ${r.capacity})</option>`;
        });

        // Render Rooms table
        const tbody = document.getElementById('roomsTableBody');
        tbody.innerHTML = state.rooms.map(r => `
            <tr>
                <td><strong>${r.block_name}</strong></td>
                <td>Room ${r.room_number}</td>
                <td><span class="badge">${r.capacity} Persons</span></td>
                <td><span class="badge ${r.current_occupancy >= r.capacity ? 'status-badge critical' : 'status-badge in-progress'}">${r.current_occupancy || 0} Students</span></td>
            </tr>
        `).join('');
    } catch (err) {
        console.error('Failed to load rooms:', err);
    }
}

async function loadWardenStudents() {
    try {
        const res = await apiFetch('/student');
        const tbody = document.getElementById('studentsTableBody');
        tbody.innerHTML = res.students.map(s => `
            <tr>
                <td><strong class="text-accent">${s.srn}</strong></td>
                <td>${s.name}</td>
                <td>${s.block_name} - Room ${s.room_number}</td>
                <td>${s.email}</td>
                <td><span class="status-badge resolved">Active</span></td>
            </tr>
        `).join('');
    } catch (err) {
        console.error('Failed to load students:', err);
    }
}

async function loadWardenStaff() {
    try {
        const res = await apiFetch('/staff');
        const tbody = document.getElementById('staffTableBody');
        tbody.innerHTML = res.staff.map(st => `
            <tr>
                <td><strong>${st.name}</strong></td>
                <td><span class="role-pill staff-pill">${st.role}</span></td>
                <td>${st.email}</td>
                <td>${st.assigned_categories && st.assigned_categories.length ? st.assigned_categories.join(', ') : 'Unassigned'}</td>
            </tr>
        `).join('');

        // Populate category checkboxes for staff creation
        const catBox = document.getElementById('staffCategoryCheckboxes');
        if (state.categories.length > 0) {
            catBox.innerHTML = state.categories.map(cat => `
                <label style="font-size:0.8rem;">
                    <input type="checkbox" name="staffCategory" value="${cat.category_id}"> ${cat.category_name}
                </label>
            `).join('');
        }
    } catch (err) {
        console.error('Failed to load staff:', err);
    }
}

// Warden Sub Tabs
window.switchWardenTab = function(tabId) {
    document.querySelectorAll('#wardenSection .admin-tab-content').forEach(tc => tc.classList.add('hidden'));
    document.querySelectorAll('#wardenSection .admin-tab-btn').forEach(tb => tb.classList.remove('active'));

    document.getElementById(tabId).classList.remove('hidden');
    event.currentTarget.classList.add('active');
};

async function handleCreateStudent(e) {
    e.preventDefault();
    const alertBox = document.getElementById('studentFormAlert');
    alertBox.classList.add('hidden');

    const srn = document.getElementById('stuSrnInput').value.trim();
    const name = document.getElementById('stuNameInput').value.trim();
    const email = document.getElementById('stuEmailInput').value.trim();
    const phone = document.getElementById('stuPhoneInput').value.trim();
    const roomId = document.getElementById('stuRoomSelect').value;

    try {
        const res = await apiFetch('/student/create', {
            method: 'POST',
            body: JSON.stringify({ srn, name, email, phone, room_id: roomId })
        });

        alertBox.className = 'alert alert-success';
        alertBox.textContent = res.message + ` (Username: ${res.student.credentials.username}, Pass: ${res.student.credentials.password})`;
        alertBox.classList.remove('hidden');

        document.getElementById('createStudentForm').reset();
        loadWardenStudents();
    } catch (err) {
        alertBox.className = 'alert alert-error';
        alertBox.textContent = err.message || 'Failed to create student.';
        alertBox.classList.remove('hidden');
    }
}

async function handleCreateStaff(e) {
    e.preventDefault();
    const alertBox = document.getElementById('staffFormAlert');
    alertBox.classList.add('hidden');

    const name = document.getElementById('staffNameInput').value.trim();
    const email = document.getElementById('staffEmailInput').value.trim();
    const role = document.getElementById('staffRoleInput').value.trim();
    const categoryIds = Array.from(document.querySelectorAll('input[name="staffCategory"]:checked')).map(c => parseInt(c.value));

    try {
        const res = await apiFetch('/staff/create', {
            method: 'POST',
            body: JSON.stringify({ name, email, role, category_ids: categoryIds })
        });

        alertBox.className = 'alert alert-success';
        alertBox.textContent = res.message;
        alertBox.classList.remove('hidden');

        document.getElementById('createStaffForm').reset();
        loadWardenStaff();
    } catch (err) {
        alertBox.className = 'alert alert-error';
        alertBox.textContent = err.message || 'Failed to create staff account.';
        alertBox.classList.remove('hidden');
    }
}

async function handleCreateRoom(e) {
    e.preventDefault();
    const alertBox = document.getElementById('roomFormAlert');
    alertBox.classList.add('hidden');

    const blockId = document.getElementById('roomBlockSelect').value;
    const roomNumber = document.getElementById('roomNumberInput').value.trim();
    const capacity = document.getElementById('roomCapacityInput').value;

    try {
        const res = await apiFetch('/rooms/rooms/create', {
            method: 'POST',
            body: JSON.stringify({ block_id: blockId, room_number: roomNumber, capacity })
        });

        alertBox.className = 'alert alert-success';
        alertBox.textContent = res.message;
        alertBox.classList.remove('hidden');

        document.getElementById('createRoomForm').reset();
        loadWardenRooms();
    } catch (err) {
        alertBox.className = 'alert alert-error';
        alertBox.textContent = err.message || 'Failed to create room.';
        alertBox.classList.remove('hidden');
    }
}

/* ============================================================
   CARD RENDERING & STATUS UPDATE MODAL
   ============================================================ */

function renderComplaintCards(containerId, complaintsList, showActions = false) {
    const container = document.getElementById(containerId);
    if (!complaintsList || complaintsList.length === 0) {
        container.innerHTML = `
            <div class="glass-panel" style="grid-column: 1/-1; padding: 2rem; text-align: center; color: var(--text-muted);">
                <i class="fa-solid fa-clipboard-check" style="font-size: 2.5rem; margin-bottom: 0.8rem; color: var(--accent-indigo);"></i>
                <p>No complaints found matching this criteria.</p>
            </div>
        `;
        return;
    }

    container.innerHTML = complaintsList.map(comp => {
        const statusClass = comp.status.toLowerCase().replace(' ', '-');
        const mediaHtml = comp.media && comp.media.length > 0 ? `
            <div class="media-gallery-row">
                ${comp.media.map(m => m.media_type === 'video' ? `
                    <div class="media-thumb-item" onclick="openMediaModal('${m.media_url}', 'video')" style="display:flex;align-items:center;justify-content:center;background:#000;color:#fff;">
                        <i class="fa-solid fa-play"></i>
                    </div>
                ` : `
                    <img class="media-thumb-item" src="${m.media_url}" onclick="openMediaModal('${m.media_url}', 'photo')" alt="Complaint evidence">
                `).join('')}
            </div>
        ` : '';

        const historyHtml = comp.history && comp.history.length > 0 ? `
            <div style="font-size:0.75rem; color:var(--text-muted); background:var(--bg-secondary); padding:0.5rem; border-radius:4px; margin-bottom:0.8rem;">
                <i class="fa-solid fa-clock-rotate-left"></i> <strong>Last Remark:</strong> ${comp.history[comp.history.length - 1].remarks || 'Status updated'}
            </div>
        ` : '';

        return `
            <div class="complaint-card glass-panel">
                <div>
                    <div class="card-top">
                        <span class="category-tag">${comp.category_name}</span>
                        <span class="status-badge ${statusClass}">
                            <i class="fa-solid fa-circle-dot"></i> ${comp.status}
                        </span>
                    </div>

                    <h4 class="comp-title">#${comp.complaint_id} - ${comp.title}</h4>
                    <p class="comp-desc">${comp.description}</p>

                    <div class="comp-meta">
                        <span><i class="fa-solid fa-building"></i> ${comp.block_name} - Room ${comp.room_number}</span>
                        <span><i class="fa-solid fa-flag"></i> Priority: <strong>${comp.priority}</strong></span>
                        <span><i class="fa-solid fa-user-gear"></i> Staff: <strong>${comp.assigned_staff_name || 'Assigned'}</strong></span>
                        <span><i class="fa-solid fa-calendar"></i> ${new Date(comp.created_at).toLocaleDateString()}</span>
                    </div>

                    ${mediaHtml}
                    ${historyHtml}
                </div>

                ${showActions ? `
                    <div class="card-actions">
                        <button class="btn btn-primary btn-block" onclick="openStatusModal(${comp.complaint_id}, '${comp.status}')">
                            <i class="fa-solid fa-pen-to-square"></i> Update Status
                        </button>
                    </div>
                ` : ''}
            </div>
        `;
    }).join('');
}

// Modal Handlers
window.openStatusModal = function(complaintId, currentStatus) {
    document.getElementById('modalComplaintId').value = complaintId;
    document.getElementById('modalStatusSelect').value = currentStatus;
    document.getElementById('modalRemarksInput').value = '';
    document.getElementById('modalAlert').classList.add('hidden');
    document.getElementById('statusModal').classList.remove('hidden');
};

window.closeStatusModal = function() {
    document.getElementById('statusModal').classList.add('hidden');
};

async function handleStatusUpdateSubmit(e) {
    e.preventDefault();
    const alertBox = document.getElementById('modalAlert');
    alertBox.classList.add('hidden');

    const complaintId = document.getElementById('modalComplaintId').value;
    const status = document.getElementById('modalStatusSelect').value;
    const remarks = document.getElementById('modalRemarksInput').value.trim();

    try {
        const res = await apiFetch(`/complaints/${complaintId}/status`, {
            method: 'PATCH',
            body: JSON.stringify({ status, remarks })
        });

        closeStatusModal();

        // Refresh views
        if (state.user.role === 'STAFF') loadStaffComplaints();
        if (state.user.role === 'WARDEN') loadWardenMasterComplaints();
    } catch (err) {
        alertBox.className = 'alert alert-error';
        alertBox.textContent = err.message || 'Failed to update status.';
        alertBox.classList.remove('hidden');
    }
}

window.openMediaModal = function(url, type) {
    const content = document.getElementById('mediaModalContent');
    if (type === 'video') {
        content.innerHTML = `<video src="${url}" controls autoplay style="max-width:100%; border-radius:8px;"></video>`;
    } else {
        content.innerHTML = `<img src="${url}" alt="Evidence full view" style="max-width:100%; border-radius:8px;">`;
    }
    document.getElementById('mediaModal').classList.remove('hidden');
};

window.closeMediaModal = function() {
    document.getElementById('mediaModal').classList.add('hidden');
    document.getElementById('mediaModalContent').innerHTML = '';
};
