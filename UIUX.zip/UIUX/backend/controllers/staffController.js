const db = require('../config/db');
const bcrypt = require('bcryptjs');

// GET ALL STAFF (WARDEN API)
async function getAllStaff(req, res) {
    try {
        const staffList = await db.query(
            `SELECT ST.*, U.username
             FROM STAFF ST
             LEFT JOIN USER_ACCOUNT U ON ST.staff_id = U.staff_id
             ORDER BY ST.staff_id ASC`
        );
        res.status(200).json({ success: true, staff: staffList });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch staff members.' });
    }
}

// CREATE STAFF ACCOUNT (WARDEN API)
async function createStaff(req, res) {
    try {
        const { name, email, phone, role, category_ids } = req.body;
        if (!name || !email || !role) {
            return res.status(400).json({ success: false, message: 'Name, Email, and Role are required.' });
        }

        // Insert into STAFF table
        const result = await db.query(
            `INSERT INTO STAFF (name, email, phone, role) VALUES (?, ?, ?, ?)`,
            [name, email, phone || '', role]
        );
        const staffId = result.insertId;

        // Auto generate staff login credentials
        const username = email.split('@')[0];
        const salt = await bcrypt.genSalt(10);
        const passwordHash = await bcrypt.hash('password123', salt);

        await db.query(
            `INSERT INTO USER_ACCOUNT (username, password_hash, role, staff_id) VALUES (?, ?, 'STAFF', ?)`,
            [username, passwordHash, staffId]
        );

        // Map Staff to Complaint Categories if provided
        if (category_ids && Array.isArray(category_ids)) {
            for (let catId of category_ids) {
                await db.query(
                    `INSERT INTO STAFF_CATEGORY (staff_id, category_id) VALUES (?, ?)`,
                    [staffId, catId]
                );
            }
        }

        res.status(201).json({
            success: true,
            message: 'Staff account created and assigned successfully.',
            staff: {
                staff_id: staffId,
                name,
                email,
                role,
                credentials: { username, password: 'password123' }
            }
        });
    } catch (error) {
        console.error('Create staff error:', error);
        res.status(500).json({ success: false, message: 'Failed to create staff account.' });
    }
}

// CONFIGURE STAFF CATEGORY MAPPING (WARDEN API)
async function updateStaffCategory(req, res) {
    try {
        const { staff_id, category_ids } = req.body;
        if (!staff_id || !Array.isArray(category_ids)) {
            return res.status(400).json({ success: false, message: 'staff_id and category_ids array are required.' });
        }

        // Clear existing mappings
        await db.query(`DELETE FROM STAFF_CATEGORY WHERE staff_id = ?`, [staff_id]);

        // Insert new category mappings
        for (let catId of category_ids) {
            await db.query(
                `INSERT INTO STAFF_CATEGORY (staff_id, category_id) VALUES (?, ?)`,
                [staff_id, catId]
            );
        }

        res.status(200).json({ success: true, message: 'Staff category mappings updated successfully.' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to update staff category mapping.' });
    }
}

module.exports = {
    getAllStaff,
    createStaff,
    updateStaffCategory
};
