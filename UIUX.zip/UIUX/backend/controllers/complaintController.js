const db = require('../config/db');

// CREATE COMPLAINT (STUDENT API)
async function createComplaint(req, res) {
    try {
        const studentId = req.user.student_id;
        if (!studentId) {
            return res.status(403).json({ success: false, message: 'Only authenticated students can submit complaints.' });
        }

        const { category_id, title, description, priority } = req.body;

        if (!category_id || !title || !description) {
            return res.status(400).json({ success: false, message: 'Category, Title, and Description are required.' });
        }

        const studentQuery = await db.query(
            `SELECT student_id, room_id FROM STUDENT WHERE student_id = ?`,
            [studentId]
        );

        if (!studentQuery || studentQuery.length === 0) {
            return res.status(404).json({ success: false, message: 'Authenticated student record not found.' });
        }

        const actualRoomId = studentQuery[0].room_id;
        const validPriority = ['Low', 'Medium', 'High', 'Critical'].includes(priority) ? priority : 'Medium';

        // 1. Insert Complaint Record
        const complaintResult = await db.query(
            `INSERT INTO COMPLAINT (room_id, reported_by, category_id, title, description, priority, status)
             VALUES (?, ?, ?, ?, ?, ?, 'Pending')`,
            [actualRoomId, studentId, category_id, title, description, validPriority]
        );

        const complaintId = complaintResult.insertId;

        // 2. Handle Media Files Uploaded
        const uploadedMedia = [];
        if (req.files && req.files.length > 0) {
            for (const file of req.files) {
                const mediaType = file.mimetype.startsWith('video/') ? 'video' : 'photo';
                const mediaUrl = `/uploads/${file.filename}`;

                await db.query(
                    `INSERT INTO COMPLAINT_MEDIA (complaint_id, media_type, media_url) VALUES (?, ?, ?)`,
                    [complaintId, mediaType, mediaUrl]
                );

                uploadedMedia.push({ media_type: mediaType, media_url: mediaUrl });
            }
        }

        // 3. AUTOMATIC STAFF ASSIGNMENT (V1 Rule #9)
        const staffMapping = await db.query(
            `SELECT staff_id FROM STAFF_CATEGORY WHERE category_id = ? LIMIT 1`,
            [category_id]
        );

        let assignedStaffId = null;
        if (staffMapping && staffMapping.length > 0) {
            assignedStaffId = staffMapping[0].staff_id;
            await db.query(
                `INSERT INTO COMPLAINT_ASSIGNMENT (complaint_id, staff_id) VALUES (?, ?)`,
                [complaintId, assignedStaffId]
            );
        }

        // 4. Record Initial Status in Status History
        await db.query(
            `INSERT INTO COMPLAINT_STATUS_HISTORY (complaint_id, status, changed_by, remarks)
             VALUES (?, 'Pending', ?, 'Complaint submitted by student. Automatically assigned.')`,
            [complaintId, assignedStaffId || 1]
        );

        const newComplaints = await db.query(
            `SELECT C.*, CC.category_name, S.name as student_name, S.srn as student_srn,
                    R.room_number, B.block_name, ST.name as assigned_staff_name
             FROM COMPLAINT C
             JOIN COMPLAINT_CATEGORY CC ON C.category_id = CC.category_id
             JOIN STUDENT S ON C.reported_by = S.student_id
             JOIN ROOM R ON C.room_id = R.room_id
             JOIN BLOCK B ON R.block_id = B.block_id
             LEFT JOIN COMPLAINT_ASSIGNMENT CA ON C.complaint_id = CA.complaint_id
             LEFT JOIN STAFF ST ON CA.staff_id = ST.staff_id
             WHERE C.complaint_id = ?`,
            [complaintId]
        );

        res.status(201).json({
            success: true,
            message: 'Complaint submitted successfully and automatically assigned to maintenance staff.',
            complaint: {
                ...newComplaints[0],
                media: uploadedMedia
            }
        });
    } catch (error) {
        console.error('Error creating complaint:', error);
        res.status(500).json({ success: false, message: 'Failed to create complaint.' });
    }
}

// GET COMPLAINTS LIST (Role Aware)
async function getComplaints(req, res) {
    try {
        const { role, student_id, staff_id } = req.user;
        let complaints = [];

        if (role === 'STUDENT') {
            complaints = await db.query(
                `SELECT C.*, CC.category_name, R.room_number, B.block_name,
                        ST.name as assigned_staff_name, ST.role as assigned_staff_role
                 FROM COMPLAINT C
                 JOIN COMPLAINT_CATEGORY CC ON C.category_id = CC.category_id
                 JOIN ROOM R ON C.room_id = R.room_id
                 JOIN BLOCK B ON R.block_id = B.block_id
                 LEFT JOIN COMPLAINT_ASSIGNMENT CA ON C.complaint_id = CA.complaint_id
                 LEFT JOIN STAFF ST ON CA.staff_id = ST.staff_id
                 WHERE C.reported_by = ?
                 ORDER BY C.created_at DESC`,
                [student_id]
            );
        } else if (role === 'STAFF') {
            complaints = await db.query(
                `SELECT C.*, CC.category_name, S.name as student_name, S.srn as student_srn,
                        S.phone as student_phone, R.room_number, B.block_name
                 FROM COMPLAINT C
                 JOIN COMPLAINT_CATEGORY CC ON C.category_id = CC.category_id
                 JOIN STUDENT S ON C.reported_by = S.student_id
                 JOIN ROOM R ON C.room_id = R.room_id
                 JOIN BLOCK B ON R.block_id = B.block_id
                 JOIN COMPLAINT_ASSIGNMENT CA ON C.complaint_id = CA.complaint_id
                 WHERE CA.staff_id = ?
                 ORDER BY C.created_at DESC`,
                [staff_id]
            );
        } else if (role === 'WARDEN') {
            complaints = await db.query(
                `SELECT C.*, CC.category_name, S.name as student_name, S.srn as student_srn,
                        R.room_number, B.block_name, ST.name as assigned_staff_name
                 FROM COMPLAINT C
                 JOIN COMPLAINT_CATEGORY CC ON C.category_id = CC.category_id
                 JOIN STUDENT S ON C.reported_by = S.student_id
                 JOIN ROOM R ON C.room_id = R.room_id
                 JOIN BLOCK B ON R.block_id = B.block_id
                 LEFT JOIN COMPLAINT_ASSIGNMENT CA ON C.complaint_id = CA.complaint_id
                 LEFT JOIN STAFF ST ON CA.staff_id = ST.staff_id
                 ORDER BY C.created_at DESC`
            );
        }

        for (let comp of complaints) {
            const media = await db.query(
                `SELECT media_id, media_type, media_url, uploaded_at FROM COMPLAINT_MEDIA WHERE complaint_id = ?`,
                [comp.complaint_id]
            );
            const history = await db.query(
                `SELECT H.*, ST.name as changed_by_name 
                 FROM COMPLAINT_STATUS_HISTORY H
                 LEFT JOIN STAFF ST ON H.changed_by = ST.staff_id
                 WHERE H.complaint_id = ?
                 ORDER BY H.changed_at ASC`,
                [comp.complaint_id]
            );
            comp.media = media;
            comp.history = history;
        }

        res.status(200).json({ success: true, count: complaints.length, complaints });
    } catch (error) {
        console.error('Error fetching complaints:', error);
        res.status(500).json({ success: false, message: 'Failed to retrieve complaints.' });
    }
}

// GET SINGLE COMPLAINT DETAILS
async function getComplaintById(req, res) {
    try {
        const complaintId = req.params.id;
        const complaints = await db.query(
            `SELECT C.*, CC.category_name, S.name as student_name, S.srn as student_srn, S.phone as student_phone,
                    R.room_number, B.block_name, ST.name as assigned_staff_name
             FROM COMPLAINT C
             JOIN COMPLAINT_CATEGORY CC ON C.category_id = CC.category_id
             JOIN STUDENT S ON C.reported_by = S.student_id
             JOIN ROOM R ON C.room_id = R.room_id
             JOIN BLOCK B ON R.block_id = B.block_id
             LEFT JOIN COMPLAINT_ASSIGNMENT CA ON C.complaint_id = CA.complaint_id
             LEFT JOIN STAFF ST ON CA.staff_id = ST.staff_id
             WHERE C.complaint_id = ?`,
            [complaintId]
        );

        if (!complaints || complaints.length === 0) {
            return res.status(404).json({ success: false, message: 'Complaint not found.' });
        }

        const complaint = complaints[0];
        complaint.media = await db.query(`SELECT * FROM COMPLAINT_MEDIA WHERE complaint_id = ?`, [complaintId]);
        complaint.history = await db.query(`SELECT * FROM COMPLAINT_STATUS_HISTORY WHERE complaint_id = ?`, [complaintId]);

        res.status(200).json({ success: true, complaint });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch complaint details.' });
    }
}

// UPDATE COMPLAINT STATUS (STAFF & WARDEN)
async function updateComplaintStatus(req, res) {
    try {
        const complaintId = req.params.id;
        const { status, remarks } = req.body;
        const { role, staff_id } = req.user;

        const validStatuses = ['Pending', 'In Progress', 'Resolved'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ success: false, message: 'Invalid status. Must be Pending, In Progress, or Resolved.' });
        }

        const complaints = await db.query(`SELECT * FROM COMPLAINT WHERE complaint_id = ?`, [complaintId]);
        if (!complaints || complaints.length === 0) {
            return res.status(404).json({ success: false, message: 'Complaint not found.' });
        }

        const resolvedAt = status === 'Resolved' ? new Date().toISOString() : null;

        await db.query(
            `UPDATE COMPLAINT SET status = ?, resolved_at = ? WHERE complaint_id = ?`,
            [status, resolvedAt, complaintId]
        );

        const changedByStaffId = staff_id || 1;
        await db.query(
            `INSERT INTO COMPLAINT_STATUS_HISTORY (complaint_id, status, changed_by, remarks)
             VALUES (?, ?, ?, ?)`,
            [complaintId, status, changedByStaffId, remarks || `Status updated to ${status}`]
        );

        if (status === 'Resolved') {
            await db.query(
                `UPDATE COMPLAINT_ASSIGNMENT SET completed_at = CURRENT_TIMESTAMP WHERE complaint_id = ?`,
                [complaintId]
            );
        }

        res.status(200).json({
            success: true,
            message: `Complaint #${complaintId} status updated to ${status}.`,
            status,
            resolved_at: resolvedAt
        });
    } catch (error) {
        console.error('Error updating status:', error);
        res.status(500).json({ success: false, message: 'Failed to update complaint status.' });
    }
}

// GET COMPLAINT CATEGORIES LIST
async function getCategories(req, res) {
    try {
        const categories = await db.query(`SELECT * FROM COMPLAINT_CATEGORY ORDER BY category_id ASC`);
        res.status(200).json({ success: true, categories });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch categories.' });
    }
}

module.exports = {
    createComplaint,
    getComplaints,
    getComplaintById,
    updateComplaintStatus,
    getCategories
};
