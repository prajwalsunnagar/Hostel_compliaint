const db = require('../config/db');
const bcrypt = require('bcryptjs');

// STUDENT DASHBOARD DATA
async function getDashboard(req, res) {
    try {
        const studentId = req.user.student_id;
        if (!studentId) {
            return res.status(400).json({ success: false, message: 'Student ID missing from session.' });
        }

        // Fetch student profile + room + block
        const studentQuery = await db.query(
            `SELECT S.student_id, S.srn, S.name, S.email, S.phone, S.room_id,
                    R.room_number, R.capacity, B.block_id, B.block_name
             FROM STUDENT S
             JOIN ROOM R ON S.room_id = R.room_id
             JOIN BLOCK B ON R.block_id = B.block_id
             WHERE S.student_id = ?`,
            [studentId]
        );

        if (!studentQuery || studentQuery.length === 0) {
            return res.status(404).json({ success: false, message: 'Student profile not found.' });
        }

        const student = studentQuery[0];

        // Fetch roommates living in the same room
        let roommates = [];
        if (student.roommates_json) {
            try { roommates = JSON.parse(student.roommates_json); } catch(e){}
        } else {
            roommates = await db.query(
                `SELECT student_id, srn, name, email, phone 
                 FROM STUDENT 
                 WHERE room_id = ? AND student_id != ?`,
                [student.room_id, studentId]
            );
        }

        res.status(200).json({
            success: true,
            dashboard: {
                student_id: student.student_id,
                srn: student.srn,
                name: student.name,
                email: student.email,
                phone: student.phone,
                block: {
                    block_id: student.block_id,
                    block_name: student.block_name
                },
                room: {
                    room_id: student.room_id,
                    room_number: student.room_number,
                    capacity: student.capacity
                },
                roommates
            }
        });
    } catch (error) {
        console.error('Error fetching student dashboard:', error);
        res.status(500).json({ success: false, message: 'Failed to load student dashboard.' });
    }
}

// WARDEN API: GET ALL STUDENTS
async function getAllStudents(req, res) {
    try {
        const students = await db.query(
            `SELECT S.student_id, S.srn, S.name, S.email, S.phone, S.room_id,
                    R.room_number, R.capacity, B.block_name
             FROM STUDENT S
             JOIN ROOM R ON S.room_id = R.room_id
             JOIN BLOCK B ON R.block_id = B.block_id
             ORDER BY S.student_id DESC`
        );
        res.status(200).json({ success: true, students });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to retrieve students list.' });
    }
}

// WARDEN API: CREATE STUDENT ACCOUNT
async function createStudent(req, res) {
    try {
        const { srn, name, email, phone, room_id, password } = req.body;
        if (!srn || !name || !email || !room_id) {
            return res.status(400).json({ success: false, message: 'SRN, Name, Email, and Room allocation are required.' });
        }

        // Insert Student
        const result = await db.query(
            `INSERT INTO STUDENT (srn, name, email, phone, room_id) VALUES (?, ?, ?, ?, ?)`,
            [srn, name, email, phone || '', room_id]
        );

        const studentId = result.insertId;

        // Hash default password or custom password
        const initialPass = password || 'password123';
        const salt = await bcrypt.genSalt(10);
        const passwordHash = await bcrypt.hash(initialPass, salt);

        // Create User Account linked to student
        await db.query(
            `INSERT INTO USER_ACCOUNT (username, password_hash, role, student_id) VALUES (?, ?, 'STUDENT', ?)`,
            [srn, passwordHash, studentId]
        );

        res.status(201).json({
            success: true,
            message: 'Student account created successfully.',
            student: {
                student_id: studentId,
                srn,
                name,
                email,
                room_id,
                credentials: { username: srn, password: initialPass }
            }
        });
    } catch (error) {
        console.error('Create student error:', error);
        res.status(500).json({ success: false, message: 'Failed to create student account. Ensure SRN & Email are unique.' });
    }
}

module.exports = {
    getDashboard,
    getAllStudents,
    createStudent
};
