const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../config/db');

const JWT_SECRET = process.env.JWT_SECRET || 'hostel_complaint_secret_key_2026_v1_super_secure';

// LOGIN API
async function login(req, res) {
    try {
        const { username, password } = req.body;
        if (!username || !password) {
            return res.status(400).json({ success: false, message: 'Username and password are required.' });
        }

        const users = await db.query(
            `SELECT user_id, username, password_hash, role, student_id, staff_id, is_active 
             FROM USER_ACCOUNT WHERE username = ?`,
            [username]
        );

        if (!users || users.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid username or password.' });
        }

        const user = users[0];

        if (!user.is_active) {
            return res.status(403).json({ success: false, message: 'User account is deactivated. Contact Warden.' });
        }

        // Demo password allowance or bcrypt check
        let isMatch = false;
        if (password === 'password123' || password === 'admin123') {
            isMatch = true;
        } else {
            try {
                isMatch = await bcrypt.compare(password, user.password_hash);
            } catch (e) {
                isMatch = (password === 'password123');
            }
        }

        if (!isMatch) {
            return res.status(401).json({ success: false, message: 'Invalid username or password.' });
        }

        // Generate JWT Token
        const token = jwt.sign(
            {
                user_id: user.user_id,
                username: user.username,
                role: user.role,
                student_id: user.student_id,
                staff_id: user.staff_id
            },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        // Retrieve role metadata
        let profile = null;
        if (user.role === 'STUDENT' && user.student_id) {
            const studentDetails = await db.query(
                `SELECT S.student_id, S.srn, S.name, S.email, S.phone, S.room_id,
                        R.room_number, R.capacity, B.block_id, B.block_name
                 FROM STUDENT S
                 JOIN ROOM R ON S.room_id = R.room_id
                 JOIN BLOCK B ON R.block_id = B.block_id
                 WHERE S.student_id = ?`,
                [user.student_id]
            );
            if (studentDetails.length > 0) profile = studentDetails[0];
        } else if (user.role === 'STAFF' && user.staff_id) {
            const staffDetails = await db.query(`SELECT * FROM STAFF WHERE staff_id = ?`, [user.staff_id]);
            if (staffDetails.length > 0) profile = staffDetails[0];
        } else if (user.role === 'WARDEN') {
            profile = { name: 'Hostel Warden / Administrator', role: 'WARDEN' };
        }

        res.status(200).json({
            success: true,
            message: 'Login successful',
            token,
            user: {
                user_id: user.user_id,
                username: user.username,
                role: user.role,
                student_id: user.student_id,
                staff_id: user.staff_id,
                profile
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ success: false, message: 'Internal server error during login' });
    }
}

// GET CURRENT USER PROFILE
async function getMe(req, res) {
    try {
        const { user_id, role, student_id, staff_id } = req.user;
        let profile = null;

        if (role === 'STUDENT' && student_id) {
            const studentDetails = await db.query(
                `SELECT S.student_id, S.srn, S.name, S.email, S.phone, S.room_id,
                        R.room_number, R.capacity, B.block_id, B.block_name
                 FROM STUDENT S
                 JOIN ROOM R ON S.room_id = R.room_id
                 JOIN BLOCK B ON R.block_id = B.block_id
                 WHERE S.student_id = ?`,
                [student_id]
            );
            profile = studentDetails[0] || null;
        } else if (role === 'STAFF' && staff_id) {
            const staffDetails = await db.query(`SELECT * FROM STAFF WHERE staff_id = ?`, [staff_id]);
            profile = staffDetails[0] || null;
        } else if (role === 'WARDEN') {
            profile = { name: 'Hostel Warden / Administrator', role: 'WARDEN' };
        }

        res.status(200).json({
            success: true,
            user: {
                ...req.user,
                profile
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to retrieve profile' });
    }
}

module.exports = {
    login,
    getMe
};
