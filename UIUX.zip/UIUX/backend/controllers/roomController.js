const db = require('../config/db');

// GET ALL BLOCKS
async function getBlocks(req, res) {
    try {
        const blocks = await db.query(`SELECT * FROM BLOCK ORDER BY block_id ASC`);
        res.status(200).json({ success: true, blocks });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch blocks.' });
    }
}

// GET ALL ROOMS (WITH OCCUPANCY METRICS)
async function getRooms(req, res) {
    try {
        const rooms = await db.query(
            `SELECT R.room_id, R.block_id, R.room_number, R.capacity, B.block_name
             FROM ROOM R
             JOIN BLOCK B ON R.block_id = B.block_id
             ORDER BY B.block_name, R.room_number ASC`
        );
        res.status(200).json({ success: true, rooms });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch rooms.' });
    }
}

// CREATE ROOM (WARDEN API - FR-03)
async function createRoom(req, res) {
    try {
        const { block_id, room_number, capacity } = req.body;
        if (!block_id || !room_number || !capacity) {
            return res.status(400).json({ success: false, message: 'Block ID, Room Number, and Capacity are required.' });
        }

        const result = await db.query(
            `INSERT INTO ROOM (block_id, room_number, capacity) VALUES (?, ?, ?)`,
            [block_id, room_number, capacity]
        );

        res.status(201).json({
            success: true,
            message: 'Room created successfully.',
            room: {
                room_id: result.insertId,
                block_id,
                room_number,
                capacity
            }
        });
    } catch (error) {
        console.error('Create room error:', error);
        res.status(500).json({ success: false, message: 'Failed to create room. Room number may already exist in this block.' });
    }
}

// ALLOCATE STUDENT TO ROOM (WARDEN API - FR-04)
async function allocateRoom(req, res) {
    try {
        const { student_id, room_id } = req.body;
        if (!student_id || !room_id) {
            return res.status(400).json({ success: false, message: 'Student ID and Room ID are required.' });
        }

        await db.query(`UPDATE STUDENT SET room_id = ? WHERE student_id = ?`, [room_id, student_id]);

        res.status(200).json({ success: true, message: 'Student allocated to room successfully.' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to allocate student to room.' });
    }
}

module.exports = {
    getBlocks,
    getRooms,
    createRoom,
    allocateRoom
};
