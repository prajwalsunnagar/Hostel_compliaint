require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const authRoutes = require('./routes/authRoutes');
const studentRoutes = require('./routes/studentRoutes');
const complaintRoutes = require('./routes/complaintRoutes');
const staffRoutes = require('./routes/staffRoutes');
const roomRoutes = require('./routes/roomRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Enable CORS & JSON Parsing
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve Uploads Directory statically
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/uploads', express.static(uploadsDir));

// Serve Frontend statically if available
const frontendDir = path.join(__dirname, '../frontend');
if (fs.existsSync(frontendDir)) {
    app.use(express.static(frontendDir));
}

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/student', studentRoutes);
app.use('/api/complaints', complaintRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/rooms', roomRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'online',
        service: 'Hostel Complaint Management System V1 Backend',
        timestamp: new Date().toISOString()
    });
});

// Fallback index.html route for SPA
app.get('*', (req, res) => {
    if (req.path.startsWith('/api') || req.path.startsWith('/uploads')) {
        return res.status(404).json({ success: false, message: 'API Endpoint Not Found' });
    }
    const indexPath = path.join(frontendDir, 'index.html');
    if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
    } else {
        res.send('Hostel Complaint Management System Backend is Running.');
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(` 🚀 HOSTEL COMPLAINT MANAGEMENT SYSTEM - BACKEND (V1)`);
    console.log(` 🌐 Server running at: http://localhost:${PORT}`);
    console.log(` 📁 Serving uploaded media at: http://localhost:${PORT}/uploads`);
    console.log(`=======================================================`);
});

module.exports = app;
