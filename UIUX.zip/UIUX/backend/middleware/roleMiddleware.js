function authorizeRoles(...allowedRoles) {
    return (req, res, next) => {
        if (!req.user || !req.user.role) {
            return res.status(401).json({ success: false, message: 'Unauthorized user.' });
        }

        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ 
                success: false, 
                message: `Forbidden: Access restricted to roles: ${allowedRoles.join(', ')}` 
            });
        }

        next();
    };
}

module.exports = authorizeRoles;
