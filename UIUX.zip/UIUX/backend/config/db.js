const mysql = require('mysql2/promise');
const path = require('path');
const fs = require('fs');

let pool = null;
let isMysql = false;

// In-Memory / File Database Store
class SimpleDbStore {
    constructor() {
        this.resetData();
    }

    resetData() {
        this.tables = {
            BLOCK: [
                { block_id: 1, block_name: 'IT' },
                { block_id: 2, block_name: 'IH' },
                { block_id: 3, block_name: 'NB' },
                { block_id: 4, block_name: 'MM' }
            ],
            COMPLAINT_CATEGORY: [
                { category_id: 1, category_name: 'Electrical' },
                { category_id: 2, category_name: 'Water Supply' },
                { category_id: 3, category_name: 'Wi-Fi / Internet' },
                { category_id: 4, category_name: 'Cleanliness' },
                { category_id: 5, category_name: 'Food / Mess' },
                { category_id: 6, category_name: 'Room Maintenance' },
                { category_id: 7, category_name: 'Furniture' },
                { category_id: 8, category_name: 'Safety / Security' },
                { category_id: 9, category_name: 'Other' }
            ],
            ROOM: [
                { room_id: 101, block_id: 4, room_number: '401', capacity: 2 },
                { room_id: 102, block_id: 4, room_number: '402', capacity: 3 },
                { room_id: 103, block_id: 4, room_number: '403', capacity: 4 },
                { room_id: 104, block_id: 1, room_number: '101', capacity: 2 },
                { room_id: 105, block_id: 1, room_number: '102', capacity: 2 },
                { room_id: 106, block_id: 2, room_number: '201', capacity: 3 },
                { room_id: 107, block_id: 3, room_number: '301', capacity: 2 }
            ],
            STAFF: [
                { staff_id: 1, name: 'Rajesh Kumar', email: 'electrician@hostel.com', phone: '+91 9876543210', role: 'Electrician' },
                { staff_id: 2, name: 'Suresh Patel', email: 'plumber@hostel.com', phone: '+91 9876543211', role: 'Plumber' },
                { staff_id: 3, name: 'Vikram Sharma', email: 'network@hostel.com', phone: '+91 9876543212', role: 'Network Technician' },
                { staff_id: 4, name: 'Ramesh Verma', email: 'cleaner@hostel.com', phone: '+91 9876543213', role: 'Cleaner' },
                { staff_id: 5, name: 'Anil Gupta', email: 'carpenter@hostel.com', phone: '+91 9876543214', role: 'Carpenter' }
            ],
            STAFF_CATEGORY: [
                { staff_id: 1, category_id: 1 },
                { staff_id: 2, category_id: 2 },
                { staff_id: 3, category_id: 3 },
                { staff_id: 4, category_id: 4 },
                { staff_id: 4, category_id: 5 },
                { staff_id: 5, category_id: 6 },
                { staff_id: 5, category_id: 7 },
                { staff_id: 5, category_id: 8 },
                { staff_id: 5, category_id: 9 }
            ],
            STUDENT: [
                { student_id: 1, srn: 'PES1UG22CS001', name: 'Aarav Mehta', email: 'aarav.m@pes.edu', phone: '+91 9123456780', room_id: 101 },
                { student_id: 2, srn: 'PES1UG22CS002', name: 'Rohan Das', email: 'rohan.d@pes.edu', phone: '+91 9123456781', room_id: 101 },
                { student_id: 3, srn: 'PES1UG22CS003', name: 'Karan Nair', email: 'karan.n@pes.edu', phone: '+91 9123456782', room_id: 102 },
                { student_id: 4, srn: 'PES1UG22CS004', name: 'Siddharth Rao', email: 'siddharth.r@pes.edu', phone: '+91 9123456783', room_id: 102 },
                { student_id: 5, srn: 'PES1UG22CS005', name: 'Varun Singh', email: 'varun.s@pes.edu', phone: '+91 9123456784', room_id: 102 }
            ],
            USER_ACCOUNT: [
                { user_id: 1, username: 'warden', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'WARDEN', student_id: null, staff_id: null, is_active: 1, created_at: new Date().toISOString() },
                { user_id: 2, username: 'PES1UG22CS001', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'STUDENT', student_id: 1, staff_id: null, is_active: 1, created_at: new Date().toISOString() },
                { user_id: 3, username: 'PES1UG22CS002', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'STUDENT', student_id: 2, staff_id: null, is_active: 1, created_at: new Date().toISOString() },
                { user_id: 4, username: 'PES1UG22CS003', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'STUDENT', student_id: 3, staff_id: null, is_active: 1, created_at: new Date().toISOString() },
                { user_id: 5, username: 'electrician', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'STAFF', student_id: null, staff_id: 1, is_active: 1, created_at: new Date().toISOString() },
                { user_id: 6, username: 'plumber', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'STAFF', student_id: null, staff_id: 2, is_active: 1, created_at: new Date().toISOString() },
                { user_id: 7, username: 'network', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'STAFF', student_id: null, staff_id: 3, is_active: 1, created_at: new Date().toISOString() },
                { user_id: 8, username: 'cleaner', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'STAFF', student_id: null, staff_id: 4, is_active: 1, created_at: new Date().toISOString() },
                { user_id: 9, username: 'carpenter', password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv', role: 'STAFF', student_id: null, staff_id: 5, is_active: 1, created_at: new Date().toISOString() }
            ],
            COMPLAINT: [],
            COMPLAINT_MEDIA: [],
            COMPLAINT_ASSIGNMENT: [],
            COMPLAINT_STATUS_HISTORY: []
        };
        this.autoIds = {
            BLOCK: 5, ROOM: 108, STUDENT: 6, COMPLAINT_CATEGORY: 10, STAFF: 6,
            USER_ACCOUNT: 10, COMPLAINT: 1, COMPLAINT_MEDIA: 1, COMPLAINT_ASSIGNMENT: 1, COMPLAINT_STATUS_HISTORY: 1
        };
    }
}

const dbStore = new SimpleDbStore();

async function initDb() {
    if (process.env.DB_HOST) {
        try {
            pool = mysql.createPool({
                host: process.env.DB_HOST || 'localhost',
                user: process.env.DB_USER || 'root',
                password: process.env.DB_PASSWORD || '',
                database: process.env.DB_NAME || 'hostel_complaint_manager',
                port: process.env.DB_PORT || 3306,
                waitForConnections: true,
                connectionLimit: 10,
                queueLimit: 0
            });
            const conn = await pool.getConnection();
            await conn.ping();
            conn.release();
            isMysql = true;
            console.log('✅ Connected to MySQL database successfully.');
            return;
        } catch (err) {
            console.log('ℹ️ Using embedded DB store with full seed data.');
            pool = null;
            isMysql = false;
        }
    }
}

// Unified query function supporting standard parameterized SQL
async function query(sql, params = []) {
    if (isMysql && pool) {
        const [rows] = await pool.query(sql, params);
        return rows;
    }

    const sqlClean = sql.replace(/\s+/g, ' ').trim();
    const sqlUpper = sqlClean.toUpperCase();

    // 1. SELECT USER_ACCOUNT by username
    if (sqlUpper.includes('FROM USER_ACCOUNT') && sqlUpper.includes('WHERE USERNAME =')) {
        const username = params[0];
        const user = dbStore.tables.USER_ACCOUNT.find(u => u.username === username);
        return user ? [user] : [];
    }

    // 2. SELECT STUDENT BY ID ONLY
    if (sqlUpper.includes('FROM STUDENT') && !sqlUpper.includes('JOIN') && (sqlUpper.includes('WHERE STUDENT_ID =') || sqlUpper.includes('WHERE S.STUDENT_ID ='))) {
        const studentId = params[0];
        const student = dbStore.tables.STUDENT.find(s => s.student_id == studentId);
        return student ? [student] : [];
    }

    // 3. SELECT STUDENT details with ROOM and BLOCK
    if (sqlUpper.includes('FROM STUDENT') && sqlUpper.includes('JOIN ROOM') && (sqlUpper.includes('WHERE S.STUDENT_ID =') || sqlUpper.includes('WHERE STUDENT_ID ='))) {
        const studentId = params[0];
        const student = dbStore.tables.STUDENT.find(s => s.student_id == studentId);
        if (!student) return [];
        const room = dbStore.tables.ROOM.find(r => r.room_id == student.room_id) || {};
        const block = dbStore.tables.BLOCK.find(b => b.block_id == room.block_id) || {};
        const roommates = dbStore.tables.STUDENT.filter(s => s.room_id == student.room_id && s.student_id != studentId);

        return [{
            student_id: student.student_id,
            srn: student.srn,
            name: student.name,
            email: student.email,
            phone: student.phone,
            room_id: student.room_id,
            room_number: room.room_number,
            capacity: room.capacity,
            block_id: block.block_id,
            block_name: block.block_name,
            roommates_json: JSON.stringify(roommates)
        }];
    }

    // 4. SELECT ROOMMATES FOR A ROOM
    if (sqlUpper.includes('FROM STUDENT') && sqlUpper.includes('WHERE ROOM_ID =') && sqlUpper.includes('STUDENT_ID !=')) {
        const [roomId, studentId] = params;
        return dbStore.tables.STUDENT.filter(s => s.room_id == roomId && s.student_id != studentId);
    }

    // 5. GET STAFF FOR CATEGORY (AUTOMATIC ASSIGNMENT RULE)
    if (sqlUpper.includes('FROM STAFF_CATEGORY') && sqlUpper.includes('WHERE CATEGORY_ID =')) {
        const catId = params[0];
        const sc = dbStore.tables.STAFF_CATEGORY.find(item => item.category_id == catId);
        if (!sc) {
            return [{ staff_id: 1 }];
        }
        return [{ staff_id: sc.staff_id }];
    }

    // 6. INSERT INTO COMPLAINT
    if (sqlUpper.startsWith('INSERT INTO COMPLAINT ') || sqlUpper.startsWith('INSERT INTO COMPLAINT(')) {
        const id = dbStore.autoIds.COMPLAINT++;
        const newComplaint = {
            complaint_id: id,
            room_id: params[0],
            reported_by: params[1],
            category_id: params[2],
            title: params[3],
            description: params[4],
            priority: params[5] || 'Medium',
            status: 'Pending',
            created_at: new Date().toISOString(),
            resolved_at: null
        };
        dbStore.tables.COMPLAINT.push(newComplaint);
        return { insertId: id, affectedRows: 1 };
    }

    // 7. INSERT INTO COMPLAINT_MEDIA
    if (sqlUpper.startsWith('INSERT INTO COMPLAINT_MEDIA')) {
        const id = dbStore.autoIds.COMPLAINT_MEDIA++;
        const media = {
            media_id: id,
            complaint_id: params[0],
            media_type: params[1],
            media_url: params[2],
            uploaded_at: new Date().toISOString()
        };
        dbStore.tables.COMPLAINT_MEDIA.push(media);
        return { insertId: id, affectedRows: 1 };
    }

    // 8. INSERT INTO COMPLAINT_ASSIGNMENT
    if (sqlUpper.startsWith('INSERT INTO COMPLAINT_ASSIGNMENT')) {
        const id = dbStore.autoIds.COMPLAINT_ASSIGNMENT++;
        const assign = {
            assignment_id: id,
            complaint_id: params[0],
            staff_id: params[1],
            assigned_at: new Date().toISOString(),
            completed_at: null
        };
        dbStore.tables.COMPLAINT_ASSIGNMENT.push(assign);
        return { insertId: id, affectedRows: 1 };
    }

    // 9. INSERT INTO COMPLAINT_STATUS_HISTORY
    if (sqlUpper.startsWith('INSERT INTO COMPLAINT_STATUS_HISTORY')) {
        const id = dbStore.autoIds.COMPLAINT_STATUS_HISTORY++;
        const hist = {
            history_id: id,
            complaint_id: params[0],
            status: params[1],
            changed_by: params[2],
            changed_at: new Date().toISOString(),
            remarks: params[3] || null
        };
        dbStore.tables.COMPLAINT_STATUS_HISTORY.push(hist);
        return { insertId: id, affectedRows: 1 };
    }

    // 10. SELECT COMPLAINT_MEDIA (Specifically check before general FROM COMPLAINT)
    if (sqlUpper.includes('FROM COMPLAINT_MEDIA')) {
        const compId = params[0];
        return dbStore.tables.COMPLAINT_MEDIA.filter(m => m.complaint_id == compId);
    }

    // 11. SELECT COMPLAINT_STATUS_HISTORY (Specifically check before general FROM COMPLAINT)
    if (sqlUpper.includes('FROM COMPLAINT_STATUS_HISTORY')) {
        const compId = params[0];
        return dbStore.tables.COMPLAINT_STATUS_HISTORY
            .filter(h => h.complaint_id == compId)
            .map(h => {
                const st = dbStore.tables.STAFF.find(s => s.staff_id == h.changed_by) || {};
                return {
                    ...h,
                    changed_by_name: st.name || 'System'
                };
            });
    }

    // 12. SELECT COMPLAINTS (Student, Staff, or Warden view)
    if (sqlUpper.includes('FROM COMPLAINT')) {
        let results = dbStore.tables.COMPLAINT.map(c => {
            const student = dbStore.tables.STUDENT.find(s => s.student_id == c.reported_by) || {};
            const room = dbStore.tables.ROOM.find(r => r.room_id == c.room_id) || {};
            const block = dbStore.tables.BLOCK.find(b => b.block_id == room.block_id) || {};
            const cat = dbStore.tables.COMPLAINT_CATEGORY.find(cc => cc.category_id == c.category_id) || {};
            const assign = dbStore.tables.COMPLAINT_ASSIGNMENT.find(ca => ca.complaint_id == c.complaint_id) || {};
            const staff = dbStore.tables.STAFF.find(st => st.staff_id == assign.staff_id) || {};

            return {
                ...c,
                student_name: student.name,
                student_srn: student.srn,
                student_phone: student.phone,
                room_number: room.room_number,
                block_name: block.block_name,
                category_name: cat.category_name,
                assigned_staff_id: staff.staff_id || null,
                assigned_staff_name: staff.name || 'Unassigned',
                assigned_staff_role: staff.role || ''
            };
        });

        // Check query filters
        if (sqlUpper.includes('WHERE CA.STAFF_ID =')) {
            const staffId = params[0];
            results = results.filter(r => r.assigned_staff_id == staffId);
        } else if (sqlUpper.includes('WHERE C.COMPLAINT_ID =') || sqlUpper.includes('WHERE COMPLAINT_ID =')) {
            const compId = params[0];
            results = results.filter(r => r.complaint_id == compId);
        } else if (sqlUpper.includes('WHERE C.REPORTED_BY =') || sqlUpper.includes('WHERE REPORTED_BY =')) {
            const studentId = params[0];
            results = results.filter(r => r.reported_by == studentId);
        }

        results.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        return results;
    }

    // 13. UPDATE COMPLAINT STATUS
    if (sqlUpper.startsWith('UPDATE COMPLAINT SET STATUS =')) {
        const [status, resolvedAt, complaintId] = params;
        const complaint = dbStore.tables.COMPLAINT.find(c => c.complaint_id == complaintId);
        if (complaint) {
            complaint.status = status;
            if (resolvedAt) complaint.resolved_at = resolvedAt;
        }
        return { affectedRows: 1 };
    }

    // 14. SELECT BLOCKS
    if (sqlUpper.includes('FROM BLOCK')) {
        return dbStore.tables.BLOCK;
    }

    // 15. SELECT COMPLAINT CATEGORIES
    if (sqlUpper.includes('FROM COMPLAINT_CATEGORY')) {
        return dbStore.tables.COMPLAINT_CATEGORY;
    }

    // 16. SELECT ROOMS
    if (sqlUpper.includes('FROM ROOM')) {
        return dbStore.tables.ROOM.map(r => {
            const b = dbStore.tables.BLOCK.find(blk => blk.block_id == r.block_id) || {};
            const studentCount = dbStore.tables.STUDENT.filter(s => s.room_id == r.room_id).length;
            return {
                ...r,
                block_name: b.block_name,
                current_occupancy: studentCount
            };
        });
    }

    // 17. SELECT STAFF LIST & CATEGORIES
    if (sqlUpper.includes('FROM STAFF')) {
        return dbStore.tables.STAFF.map(s => {
            const cats = dbStore.tables.STAFF_CATEGORY
                .filter(sc => sc.staff_id == s.staff_id)
                .map(sc => dbStore.tables.COMPLAINT_CATEGORY.find(c => c.category_id == sc.category_id)?.category_name)
                .filter(Boolean);
            return {
                ...s,
                assigned_categories: cats
            };
        });
    }

    // 18. SELECT STUDENT LIST (Warden)
    if (sqlUpper.includes('FROM STUDENT S JOIN ROOM R')) {
        return dbStore.tables.STUDENT.map(s => {
            const r = dbStore.tables.ROOM.find(rm => rm.room_id == s.room_id) || {};
            const b = dbStore.tables.BLOCK.find(blk => blk.block_id == r.block_id) || {};
            return {
                ...s,
                room_number: r.room_number,
                capacity: r.capacity,
                block_name: b.block_name
            };
        });
    }

    // 19. CREATE ROOM (Warden)
    if (sqlUpper.startsWith('INSERT INTO ROOM')) {
        const id = dbStore.autoIds.ROOM++;
        const newRoom = {
            room_id: id,
            block_id: params[0],
            room_number: params[1],
            capacity: params[2]
        };
        dbStore.tables.ROOM.push(newRoom);
        return { insertId: id, affectedRows: 1 };
    }

    // 20. CREATE STAFF (Warden)
    if (sqlUpper.startsWith('INSERT INTO STAFF')) {
        const id = dbStore.autoIds.STAFF++;
        const newStaff = {
            staff_id: id,
            name: params[0],
            email: params[1],
            phone: params[2],
            role: params[3]
        };
        dbStore.tables.STAFF.push(newStaff);

        const uId = dbStore.autoIds.USER_ACCOUNT++;
        dbStore.tables.USER_ACCOUNT.push({
            user_id: uId,
            username: params[1].split('@')[0],
            password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv',
            role: 'STAFF',
            student_id: null,
            staff_id: id,
            is_active: 1,
            created_at: new Date().toISOString()
        });

        return { insertId: id, affectedRows: 1 };
    }

    // 21. CREATE STUDENT (Warden)
    if (sqlUpper.startsWith('INSERT INTO STUDENT')) {
        const id = dbStore.autoIds.STUDENT++;
        const newStudent = {
            student_id: id,
            srn: params[0],
            name: params[1],
            email: params[2],
            phone: params[3],
            room_id: params[4]
        };
        dbStore.tables.STUDENT.push(newStudent);

        const uId = dbStore.autoIds.USER_ACCOUNT++;
        dbStore.tables.USER_ACCOUNT.push({
            user_id: uId,
            username: params[0],
            password_hash: '$2a$10$8K1p/a0dL.v.5y0Xq.1v6O.abcdefghijklmnopqrstuv',
            role: 'STUDENT',
            student_id: id,
            staff_id: null,
            is_active: 1,
            created_at: new Date().toISOString()
        });

        return { insertId: id, affectedRows: 1 };
    }

    // 22. UPDATE STAFF CATEGORY MAPPING (Warden)
    if (sqlUpper.startsWith('DELETE FROM STAFF_CATEGORY WHERE STAFF_ID =')) {
        const staffId = params[0];
        dbStore.tables.STAFF_CATEGORY = dbStore.tables.STAFF_CATEGORY.filter(sc => sc.staff_id != staffId);
        return { affectedRows: 1 };
    }

    if (sqlUpper.startsWith('INSERT INTO STAFF_CATEGORY')) {
        dbStore.tables.STAFF_CATEGORY.push({
            staff_id: params[0],
            category_id: params[1]
        });
        return { affectedRows: 1 };
    }

    return [];
}

initDb();

module.exports = {
    query,
    initDb
};
