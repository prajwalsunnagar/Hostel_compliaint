const express = require('express');
const router = express.Router();
const complaintController = require('../controllers/complaintController');
const authenticateToken = require('../middleware/authMiddleware');
const authorizeRoles = require('../middleware/roleMiddleware');
const upload = require('../middleware/uploadMiddleware');

router.get('/categories', authenticateToken, complaintController.getCategories);

// Create Complaint (Student with multi-photo and video upload)
router.post(
    '/',
    authenticateToken,
    authorizeRoles('STUDENT'),
    upload.array('media', 10), // Accept up to 10 photos/videos
    complaintController.createComplaint
);

// Get Complaints List
router.get('/', authenticateToken, complaintController.getComplaints);

// Get Single Complaint Details
router.get('/:id', authenticateToken, complaintController.getComplaintById);

// Update Status (Staff or Warden)
router.patch('/:id/status', authenticateToken, authorizeRoles('STAFF', 'WARDEN'), complaintController.updateComplaintStatus);

module.exports = router;
