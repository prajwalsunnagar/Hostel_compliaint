const express = require('express');
const router = express.Router();
const roomController = require('../controllers/roomController');
const authenticateToken = require('../middleware/authMiddleware');
const authorizeRoles = require('../middleware/roleMiddleware');

router.get('/blocks', authenticateToken, roomController.getBlocks);
router.get('/rooms', authenticateToken, roomController.getRooms);
router.post('/rooms/create', authenticateToken, authorizeRoles('WARDEN'), roomController.createRoom);
router.post('/allocate', authenticateToken, authorizeRoles('WARDEN'), roomController.allocateRoom);

module.exports = router;
