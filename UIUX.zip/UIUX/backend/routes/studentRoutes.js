const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const authenticateToken = require('../middleware/authMiddleware');
const authorizeRoles = require('../middleware/roleMiddleware');

router.get('/dashboard', authenticateToken, authorizeRoles('STUDENT'), studentController.getDashboard);
router.get('/', authenticateToken, authorizeRoles('WARDEN'), studentController.getAllStudents);
router.post('/create', authenticateToken, authorizeRoles('WARDEN'), studentController.createStudent);

module.exports = router;
