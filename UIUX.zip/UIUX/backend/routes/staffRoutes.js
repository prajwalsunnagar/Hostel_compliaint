const express = require('express');
const router = express.Router();
const staffController = require('../controllers/staffController');
const authenticateToken = require('../middleware/authMiddleware');
const authorizeRoles = require('../middleware/roleMiddleware');

router.get('/', authenticateToken, authorizeRoles('WARDEN'), staffController.getAllStaff);
router.post('/create', authenticateToken, authorizeRoles('WARDEN'), staffController.createStaff);
router.post('/category-map', authenticateToken, authorizeRoles('WARDEN'), staffController.updateStaffCategory);

module.exports = router;
